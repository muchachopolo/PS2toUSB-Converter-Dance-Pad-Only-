Welcome to LeoJoy!

LeoJoy! allows you to add video game controller functionality to the Arduino Leonardo.

You'll need to do two things - First, add this folder to your arduino/hardware folder, and you should be able to select LeoJoy! as a board to compile to.

Next, when you compile for the first time, you'll need to install the drivers.  It's the
same process you took for installing the Arduino Leonardo drivers, only this time you 
need to point Windows to this folder so it can find the LeoJoy.inf file.

Have fun!